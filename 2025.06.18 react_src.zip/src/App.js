import React, { useState, useEffect } from 'react';

function RamenTimer({ onComplete }) {
//   const [timeLeft, setTimeLeft] = useState(180); // 3분 타이머 (180초)
  const [timeLeft, setTimeLeft] = useState(5); // 3분 타이머 (180초)

  useEffect(() => {
    if (timeLeft > 0) {
      const timerId = setTimeout(() => {
        setTimeLeft(timeLeft - 1);
        console.log("타이머 살았는지 체크용:"+ timeLeft);
      }, 1000);
      
      return () => clearTimeout(timerId);
    } else {
      onComplete(); // 타이머 종료 시 부모 컴포넌트에 알림
    }
  // }, [timeLeft]);
  }, [timeLeft, onComplete]);
  // [timeLeft, onComplete]를 의존성 배열(dependency array)이라고 부름
  // 이 배열 안의 값이 변경될 때만 useEffect가 다시 실행 됨.

  // onComplete 를 쓰는 이유: 
  // 1. React의 경고 방지.
  // 2. onComplete 값(함수 참조)이 변경될 가능성 때문.


  return (
    <div style={{ textAlign: 'center', padding: '20px', fontSize: '1.5em' }}>
      남은 시간: {timeLeft}초
    </div>
  );
}

function App() {
  const [isTimerRunning, setIsTimerRunning] = useState(false); // 타이머 표시 여부
  const [resultMessage, setResultMessage] = useState(''); // 결과 메시지

  const handleStartTimer = () => {
    setIsTimerRunning(true);
    setResultMessage(''); // 타이머 시작 시 결과 메시지 초기화
  };

  const handleTimerComplete = () => {
    setIsTimerRunning(false);
    setResultMessage('너구리 라면이 완성되었습니다!');
  };

  return (
    <div style={{ textAlign: 'center', padding: '20px' }}>
      <button onClick={handleStartTimer} style={{ fontSize: '1.2em', padding: '10px' }}>
        너구리
      </button>

      {isTimerRunning && (
        <div>
          <RamenTimer onComplete={handleTimerComplete} />
        </div>
      )}

      <hr></hr>
      <hr></hr>
      <hr></hr>

      <div style={{ marginTop: '20px', fontSize: '1.5em' }}>
        {resultMessage}
      </div>
    </div>
  );
}

export default App;
